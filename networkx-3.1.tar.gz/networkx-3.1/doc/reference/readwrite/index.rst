.. _readwrite:

**************************
Reading and writing graphs
**************************

.. toctree::
   :maxdepth: 2

   adjlist
   multiline_adjlist
   edgelist
   gexf
   gml
   graphml
   json_graph
   leda
   sparsegraph6
   pajek
   matrix_market
   text

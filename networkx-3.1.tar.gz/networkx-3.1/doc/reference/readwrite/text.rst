
Network Text
============
.. automodule:: networkx.readwrite.text
.. autosummary::
   :toctree: generated/

   generate_network_text
   write_network_text

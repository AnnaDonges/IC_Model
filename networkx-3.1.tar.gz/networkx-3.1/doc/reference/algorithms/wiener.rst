************
Wiener index
************

.. automodule:: networkx.algorithms.wiener
.. autosummary::
   :toctree: generated/

   wiener_index

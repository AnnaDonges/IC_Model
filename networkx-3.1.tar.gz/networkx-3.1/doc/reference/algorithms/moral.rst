*****
Moral
*****

.. automodule:: networkx.algorithms.moral
.. autosummary::
   :toctree: generated/

   moral_graph
